package com.deivix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionApiMain {
    public static void main(String[] args) {
        SpringApplication.run(TransactionApiMain.class, args);
    }
}

